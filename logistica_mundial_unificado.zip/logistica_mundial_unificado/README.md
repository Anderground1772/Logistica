# Logística Mundial — proyecto unificado

Este paquete reúne los dos archivos ZIP originales en **un solo proyecto coherente**. La aplicación ejecutable principal es Angular + Node.js/Express + MySQL. El panel React del primer ZIP se conserva como referencia de diseño y código en `documentacion/referencia-react/`; sus indicadores de demostración no se mezclan con los datos reales de la base de datos.

## Qué contiene

- `frontend/`: aplicación Angular con panel, gestión de envíos y clientes, paquetes, flota y rastreo.
- `backend/`: API REST con Node.js, Express y conexión MySQL.
- `database/init.sql`: creación de tablas, datos de demostración y vista SQL.
- `docker-compose.yml`: levanta la base de datos, la API y el frontend.
- `deploy/kubernetes-frontend.yaml`: manifiesto Kubernetes/OpenShift original para el frontend.
- `documentacion/referencia-react/`: componente React y Dockerfile originales, conservados como referencia; no se ejecutan junto con Angular para evitar dos frontends duplicados.

## Ejecución recomendada (Docker)

Requisitos: Docker Desktop con Docker Compose.

1. Descomprime el ZIP.
2. Abre una terminal dentro de la carpeta `logistica-mundial-angular`.
3. Ejecuta:

   ```bash
   docker compose up --build
   ```

4. Abre:
   - Aplicación: http://localhost:8080
   - API: http://localhost:3000/api
   - Salud de API: http://localhost:3000/api/health

El frontend usa rutas `/api` y Nginx las redirige al backend dentro de Docker. Así no depende de una URL fija del navegador y funciona también detrás del contenedor. MySQL se inicializa con `database/init.sql` al crear el volumen por primera vez.

Para detener los servicios:

```bash
docker compose down
```

Para borrar también la base de datos local y volver a ejecutar la inicialización desde cero:

```bash
docker compose down -v
docker compose up --build
```

**Atención:** `down -v` elimina los datos guardados en el volumen local de MySQL.

## Ejecución sin Docker

Requisitos: Node.js 20+, npm y MySQL 8+.

1. Crea la base `logistica_mundial` y ejecuta `database/init.sql`.
2. Copia `backend/.env.example` como `backend/.env` y ajusta las credenciales.
3. En una terminal:

   ```bash
   cd backend
   npm install
   npm run dev
   ```

4. En otra terminal:

   ```bash
   cd frontend
   npm install
   npm start
   ```

5. Abre http://localhost:4200. El proxy de Angular reenvía `/api` a `http://localhost:3000`.

## Integración de los dos ZIP

El primer ZIP aportaba un dashboard React de ejemplo, un Dockerfile para React y un manifiesto de despliegue. El segundo aportaba la aplicación funcional de logística con Angular, API y base de datos. Para evitar incompatibilidades, se mantuvo Angular como frontend único y se conservó el código React como referencia. Se integró la configuración de despliegue Kubernetes en `deploy/` y se adaptó el frontend Angular para que la API funcione mediante proxy tanto en Docker como en desarrollo.

## Antes de publicar en internet

Las contraseñas del `docker-compose.yml` son solo para desarrollo local. Cámbialas, configura secretos fuera del repositorio y agrega autenticación/autorización, HTTPS, auditoría y copias de seguridad antes de usar el sistema en producción. El manifiesto Kubernetes conservado corresponde al frontend; el despliegue completo en un clúster requiere configurar también backend, base de datos, secretos, almacenamiento persistente e imágenes.
